// Service Worker for VidyAI++ - Offline Functionality
const CACHE_NAME = 'vidyai-cache-v1';
const CONTENT_CACHE_NAME = 'vidyai-content-cache';
const RESOURCES_CACHE_NAME = 'vidyai-resources';

// Resources to cache on install
const PRECACHE_URLS = [
  '/',
  '/offline',
  '/static/js/main.js',
  '/static/js/voice.js',
  '/static/js/vision.js',
  '/static/js/offline.js',
  '/static/css/style.css',
  '/static/manifest.json',
  'https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css',
  'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.0/font/bootstrap-icons.css',
  'https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.js'
];

// Install event - cache basic resources
self.addEventListener('install', event => {
  console.log('Service Worker installing');
  
  // Skip waiting to ensure the new service worker activates immediately
  self.skipWaiting();
  
  // Pre-cache essential resources
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Caching static resources');
        return cache.addAll(PRECACHE_URLS);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  console.log('Service Worker activating');
  
  // Claim clients to ensure they're controlled by this service worker
  self.clients.claim();
  
  // Remove old caches
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME && 
              cacheName !== CONTENT_CACHE_NAME && 
              cacheName !== RESOURCES_CACHE_NAME) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Fetch event - serve from cache or network
self.addEventListener('fetch', event => {
  // Skip cross-origin requests
  if (!event.request.url.startsWith(self.location.origin)) {
    return;
  }
  
  // Skip non-GET requests
  if (event.request.method !== 'GET') {
    return;
  }
  
  // Handle API requests differently
  if (event.request.url.includes('/api/')) {
    // For API requests, try network first, then show offline content
    event.respondWith(
      fetch(event.request)
        .catch(() => {
          // If it's a content request, try to serve cached content
          if (event.request.url.includes('get_content')) {
            return caches.match('/offline');
          }
          
          // Default response for failed API requests
          return new Response(JSON.stringify({
            error: 'You are offline. This action requires an internet connection.'
          }), {
            headers: { 'Content-Type': 'application/json' }
          });
        })
    );
    return;
  }
  
  // For normal page requests, use cache-first strategy
  event.respondWith(
    caches.match(event.request)
      .then(cachedResponse => {
        if (cachedResponse) {
          // Return cached response
          return cachedResponse;
        }
        
        // If not in cache, fetch from network
        return fetch(event.request)
          .then(response => {
            // Don't cache if not a valid response
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }
            
            // Clone the response since it can only be consumed once
            const responseToCache = response.clone();
            
            // Cache the fetched response
            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });
            
            return response;
          })
          .catch(error => {
            // If offline and requesting a page, show offline page
            if (event.request.mode === 'navigate') {
              return caches.match('/offline');
            }
            
            console.error('Fetch failed:', error);
            throw error;
          });
      })
  );
});

// Handle background sync for offline data
self.addEventListener('sync', event => {
  if (event.tag === 'sync-activities') {
    event.waitUntil(syncOfflineActivities());
  }
});

// Function to sync offline learning activities
async function syncOfflineActivities() {
  // This would normally access IndexedDB to get pending activities
  // and sync them with the server
  console.log('Background sync for offline activities');
  
  // Since we can't directly access IndexedDB from the service worker in this context,
  // we'll post a message to any open clients to trigger syncing
  const clients = await self.clients.matchAll();
  
  if (clients && clients.length > 0) {
    clients.forEach(client => {
      client.postMessage({
        type: 'SYNC_OFFLINE_DATA'
      });
    });
  }
}

// Listen for messages from clients
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'CACHE_CONTENT') {
    // Handle content caching request
    const contentData = event.data.content;
    const contentId = event.data.contentId;
    
    caches.open(CONTENT_CACHE_NAME)
      .then(cache => {
        // Create a synthetic response with the content data
        const contentResponse = new Response(JSON.stringify(contentData), {
          headers: { 'Content-Type': 'application/json' }
        });
        
        // Cache the content
        cache.put(`/api/get_content/${contentId}`, contentResponse);
        console.log(`Content ID ${contentId} cached successfully`);
        
        // Notify client that caching is complete
        if (event.source) {
          event.source.postMessage({
            type: 'CONTENT_CACHED',
            contentId: contentId,
            success: true
          });
        }
      })
      .catch(error => {
        console.error('Error caching content:', error);
        
        // Notify client about the error
        if (event.source) {
          event.source.postMessage({
            type: 'CONTENT_CACHED',
            contentId: contentId,
            success: false,
            error: error.message
          });
        }
      });
  }
});
