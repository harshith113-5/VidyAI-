// Vision-based features for VidyAI++

// Global variables
let webcam = null;
let emotionDetectionInterval = null;
let emotionDetectionActive = false;
let engagementTrackingInterval = null;
let lastEmotionData = null;
let lastEngagementData = null;

// Initialize vision features when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Initialize webcam if element exists
    const webcamElement = document.getElementById('webcam');
    const toggleVisionBtn = document.getElementById('toggle-vision-features');
    
    if (webcamElement) {
        // Setup webcam toggle button
        if (toggleVisionBtn) {
            toggleVisionBtn.addEventListener('click', function() {
                if (emotionDetectionActive) {
                    stopEmotionDetection();
                    this.textContent = 'Start Vision Features';
                    this.classList.remove('btn-danger');
                    this.classList.add('btn-success');
                } else {
                    initWebcam(webcamElement);
                    this.textContent = 'Stop Vision Features';
                    this.classList.remove('btn-success');
                    this.classList.add('btn-danger');
                }
            });
        }
        
        // Auto-start if specified
        if (webcamElement.getAttribute('data-auto-start') === 'true') {
            initWebcam(webcamElement);
            if (toggleVisionBtn) {
                toggleVisionBtn.textContent = 'Stop Vision Features';
                toggleVisionBtn.classList.remove('btn-success');
                toggleVisionBtn.classList.add('btn-danger');
            }
        }
    }
});

// Initialize webcam
function initWebcam(webcamElement) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        showError('Your browser does not support webcam access. Try using Chrome, Firefox, or Edge.');
        return;
    }
    
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
            webcamElement.srcObject = stream;
            webcam = webcamElement;
            
            // Wait for webcam to initialize before starting detection
            webcamElement.addEventListener('loadeddata', () => {
                startEmotionDetection();
            });
        })
        .catch(error => {
            console.error('Error accessing webcam:', error);
            showError('Could not access your webcam. Please check permissions and try again.');
        });
}

// Start emotion detection
function startEmotionDetection() {
    if (!webcam || emotionDetectionActive) return;
    
    emotionDetectionActive = true;
    
    // Get detection interval from data attribute or use default
    const detectionInterval = parseInt(webcam.getAttribute('data-detection-interval') || '5000', 10);
    
    // Immediately detect emotion once
    detectEmotion();
    
    // Start regular detection
    emotionDetectionInterval = setInterval(detectEmotion, detectionInterval);
    
    // Start engagement tracking if needed
    const trackEngagement = webcam.getAttribute('data-track-engagement') === 'true';
    if (trackEngagement) {
        startEngagementTracking();
    }
    
    console.log('Emotion detection started');
}

// Stop emotion detection
function stopEmotionDetection() {
    if (!emotionDetectionActive) return;
    
    clearInterval(emotionDetectionInterval);
    
    if (engagementTrackingInterval) {
        clearInterval(engagementTrackingInterval);
    }
    
    // Stop webcam
    if (webcam && webcam.srcObject) {
        const tracks = webcam.srcObject.getTracks();
        tracks.forEach(track => track.stop());
        webcam.srcObject = null;
    }
    
    emotionDetectionActive = false;
    console.log('Emotion detection stopped');
}

// Detect emotion from webcam image
function detectEmotion() {
    if (!webcam || !emotionDetectionActive) return;
    
    // Create canvas to capture image
    const canvas = document.createElement('canvas');
    canvas.width = webcam.videoWidth;
    canvas.height = webcam.videoHeight;
    const ctx = canvas.getContext('2d');
    
    // Draw current video frame to canvas
    ctx.drawImage(webcam, 0, 0, canvas.width, canvas.height);
    
    // Convert canvas to blob
    canvas.toBlob(blob => {
        // Create form data with image
        const formData = new FormData();
        formData.append('image', blob, 'webcam.jpg');
        
        // Add context if available
        const learningContext = document.querySelector('.learning-content');
        if (learningContext) {
            formData.append('context', 'learning:' + learningContext.getAttribute('data-content-id'));
        }
        
        // Send to server for emotion detection
        fetch('/api/emotion_detection', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            lastEmotionData = data;
            updateEmotionDisplay(data);
        })
        .catch(error => {
            console.error('Error detecting emotion:', error);
        });
    }, 'image/jpeg', 0.8);
}

// Start engagement tracking
function startEngagementTracking() {
    if (!webcam || !emotionDetectionActive) return;
    
    // Get tracking interval from data attribute or use default
    const trackingInterval = parseInt(webcam.getAttribute('data-engagement-interval') || '10000', 10);
    
    // Start regular tracking
    engagementTrackingInterval = setInterval(trackEngagement, trackingInterval);
    
    console.log('Engagement tracking started');
}

// Track engagement from webcam image
function trackEngagement() {
    if (!webcam || !emotionDetectionActive) return;
    
    // Create canvas to capture image
    const canvas = document.createElement('canvas');
    canvas.width = webcam.videoWidth;
    canvas.height = webcam.videoHeight;
    const ctx = canvas.getContext('2d');
    
    // Draw current video frame to canvas
    ctx.drawImage(webcam, 0, 0, canvas.width, canvas.height);
    
    // Convert canvas to blob
    canvas.toBlob(blob => {
        // Create form data with image
        const formData = new FormData();
        formData.append('image', blob, 'webcam.jpg');
        
        // Send to server for engagement tracking
        fetch('/api/track_engagement', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            lastEngagementData = data;
            updateEngagementDisplay(data);
            
            // Trigger adaptive content changes if engagement is low
            if (data.engagement_level < 0.3) {
                triggerAdaptiveContent('low_engagement', data);
            }
        })
        .catch(error => {
            console.error('Error tracking engagement:', error);
        });
    }, 'image/jpeg', 0.8);
}

// Update emotion display
function updateEmotionDisplay(emotionData) {
    const emotionDisplay = document.getElementById('emotion-display');
    const emotionIcon = document.getElementById('emotion-icon');
    
    if (!emotionDisplay || !emotionIcon) return;
    
    // Update text display
    emotionDisplay.textContent = capitalizeFirstLetter(emotionData.emotion);
    
    // Update icon
    const emotionIcons = {
        'happy': 'bi-emoji-smile',
        'sad': 'bi-emoji-frown',
        'angry': 'bi-emoji-angry',
        'surprise': 'bi-emoji-surprise',
        'fear': 'bi-emoji-dizzy',
        'disgust': 'bi-emoji-expressionless',
        'neutral': 'bi-emoji-neutral'
    };
    
    // Remove all icon classes
    emotionIcon.className = 'bi';
    
    // Add appropriate icon class
    const iconClass = emotionIcons[emotionData.emotion] || 'bi-emoji-neutral';
    emotionIcon.classList.add(iconClass);
    
    // Update progress bar if exists
    const confidenceBar = document.getElementById('emotion-confidence');
    if (confidenceBar) {
        const confidence = Math.round(emotionData.confidence * 100);
        confidenceBar.style.width = `${confidence}%`;
        confidenceBar.setAttribute('aria-valuenow', confidence);
        confidenceBar.textContent = `${confidence}%`;
    }
}

// Update engagement display
function updateEngagementDisplay(engagementData) {
    const engagementDisplay = document.getElementById('engagement-display');
    const engagementBar = document.getElementById('engagement-level');
    
    if (!engagementDisplay || !engagementBar) return;
    
    // Determine engagement level description
    let engagementText = 'Unknown';
    const level = engagementData.engagement_level;
    
    if (level > 0.8) {
        engagementText = 'Highly Engaged';
    } else if (level > 0.6) {
        engagementText = 'Engaged';
    } else if (level > 0.4) {
        engagementText = 'Moderately Engaged';
    } else if (level > 0.2) {
        engagementText = 'Slightly Distracted';
    } else {
        engagementText = 'Disengaged';
    }
    
    // Update text
    engagementDisplay.textContent = engagementText;
    
    // Update progress bar
    const engagementPercent = Math.round(level * 100);
    engagementBar.style.width = `${engagementPercent}%`;
    engagementBar.setAttribute('aria-valuenow', engagementPercent);
    
    // Change color based on level
    engagementBar.className = 'progress-bar';
    if (level > 0.6) {
        engagementBar.classList.add('bg-success');
    } else if (level > 0.3) {
        engagementBar.classList.add('bg-warning');
    } else {
        engagementBar.classList.add('bg-danger');
    }
}

// Trigger adaptive content changes based on emotion/engagement
function triggerAdaptiveContent(trigger, data) {
    // Get current content elements
    const contentContainer = document.querySelector('.learning-content');
    
    if (!contentContainer) return;
    
    const contentId = contentContainer.getAttribute('data-content-id');
    const currentStyle = contentContainer.getAttribute('data-learning-style');
    
    // Different actions based on trigger
    switch(trigger) {
        case 'low_engagement':
            // Show engagement prompt
            const engagementPrompt = document.getElementById('engagement-prompt');
            if (engagementPrompt && !engagementPrompt.classList.contains('show')) {
                engagementPrompt.classList.add('show');
                
                // Hide after 10 seconds
                setTimeout(() => {
                    engagementPrompt.classList.remove('show');
                }, 10000);
            }
            
            // Switch learning style if appropriate
            if (data.engagement_level < 0.2 && currentStyle) {
                // Suggest a different learning style
                const styles = ['visual', 'auditory', 'kinesthetic'];
                const currentIndex = styles.indexOf(currentStyle);
                const newStyle = styles[(currentIndex + 1) % styles.length];
                
                const styleSwitch = document.getElementById('style-switch-prompt');
                if (styleSwitch) {
                    styleSwitch.textContent = `Would you like to try a ${newStyle} learning approach instead?`;
                    styleSwitch.setAttribute('data-new-style', newStyle);
                    styleSwitch.classList.add('show');
                }
            }
            break;
            
        case 'frustration':
            // Suggest a simpler explanation
            const simplifyPrompt = document.getElementById('simplify-prompt');
            if (simplifyPrompt) {
                simplifyPrompt.classList.add('show');
            }
            break;
    }
}

// Accept a different learning style
function switchLearningStyle(element) {
    const newStyle = element.getAttribute('data-new-style');
    const contentId = document.querySelector('.learning-content').getAttribute('data-content-id');
    
    if (!newStyle || !contentId) return;
    
    // Send request to get content in new style
    fetch(`/api/adapt_content?content_id=${contentId}&learning_style=${newStyle}`, {
        method: 'GET'
    })
    .then(response => response.json())
    .then(data => {
        if (data.content) {
            // Update content
            document.querySelector('.learning-content-main').innerHTML = data.content;
            
            // Update style attribute
            document.querySelector('.learning-content').setAttribute('data-learning-style', newStyle);
            
            // Hide style switch prompt
            document.getElementById('style-switch-prompt').classList.remove('show');
            
            // Show feedback
            showToast(`Content adapted to ${newStyle} learning style`, 'info');
        }
    })
    .catch(error => {
        console.error('Error adapting content:', error);
    });
}

// Utility functions
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

function showError(message) {
    const errorElement = document.getElementById('vision-error');
    
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.classList.remove('d-none');
    } else {
        console.error(message);
    }
}
