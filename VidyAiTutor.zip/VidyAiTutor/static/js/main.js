// Main JavaScript functionality for VidyAI++

// Wait for DOM to load
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Check for offline mode
    checkOnlineStatus();
    
    // Setup voice navigation if enabled
    initVoiceNavigation();
    
    // Register service worker for offline functionality
    registerServiceWorker();
    
    // Initialize custom UI elements
    initUI();
});

// Check if online and handle offline mode
function checkOnlineStatus() {
    updateOnlineStatus();
    
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);
}

function updateOnlineStatus() {
    const offlineAlert = document.getElementById('offline-alert');
    
    if (!navigator.onLine) {
        if (offlineAlert) {
            offlineAlert.classList.remove('d-none');
        }
        document.body.classList.add('offline-mode');
        
        // Try to load content from cache
        loadOfflineContent();
    } else {
        if (offlineAlert) {
            offlineAlert.classList.add('d-none');
        }
        document.body.classList.remove('offline-mode');
        
        // Sync any pending data
        syncOfflineData();
    }
}

// Register service worker for PWA functionality
function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/static/js/sw.js')
            .then(registration => {
                console.log('Service Worker registered with scope:', registration.scope);
            })
            .catch(error => {
                console.error('Service Worker registration failed:', error);
            });
    }
}

// Initialize voice navigation features
function initVoiceNavigation() {
    // Function is implemented in voice.js
    // This stub prevents the "initVoiceNavigation is not defined" error
    console.log("Voice navigation initialization delegated to voice.js");
}

// Initialize UI elements and functionality
function initUI() {
    // Setup learning content interaction
    setupContentInteraction();
    
    // Setup gamification elements
    setupGamificationUI();
    
    // Setup language selector
    setupLanguageSelector();
    
    // Setup accessibility features
    setupAccessibility();
}

// Setup content interaction (expand/collapse, progress tracking)
function setupContentInteraction() {
    const contentSections = document.querySelectorAll('.content-section');
    
    contentSections.forEach(section => {
        const header = section.querySelector('.section-header');
        const content = section.querySelector('.section-content');
        
        if (header && content) {
            header.addEventListener('click', () => {
                content.classList.toggle('show');
                header.classList.toggle('expanded');
            });
        }
    });
    
    // Mark content as read/complete
    const completeButtons = document.querySelectorAll('.mark-complete-btn');
    
    completeButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            
            const contentId = this.getAttribute('data-content-id');
            const score = this.getAttribute('data-score') || 1.0;
            
            // Send completion data to server
            fetch('/complete_activity', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `score=${score}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show success message
                    const toast = new bootstrap.Toast(document.getElementById('completion-toast'));
                    toast.show();
                    
                    // Update UI
                    this.disabled = true;
                    this.textContent = 'Completed';
                    this.classList.remove('btn-primary');
                    this.classList.add('btn-success');
                }
            })
            .catch(error => {
                console.error('Error completing activity:', error);
                
                if (!navigator.onLine) {
                    // Store completion data for syncing later
                    storeOfflineCompletion(contentId, score);
                    
                    // Update UI to show offline completion
                    this.disabled = true;
                    this.textContent = 'Completed (Offline)';
                    this.classList.remove('btn-primary');
                    this.classList.add('btn-warning');
                }
            });
        });
    });
}

// Setup gamification elements (streaks, points, badges)
function setupGamificationUI() {
    // Animate points counter
    const pointsCounters = document.querySelectorAll('.points-counter');
    
    pointsCounters.forEach(counter => {
        const targetValue = parseInt(counter.getAttribute('data-points'), 10);
        const duration = 1000; // Animation duration in ms
        const steps = 20; // Number of steps in animation
        const stepValue = targetValue / steps;
        let currentValue = 0;
        let currentStep = 0;
        
        const interval = setInterval(() => {
            currentStep++;
            currentValue = Math.min(Math.round(stepValue * currentStep), targetValue);
            counter.textContent = currentValue;
            
            if (currentStep >= steps) {
                clearInterval(interval);
                counter.textContent = targetValue;
            }
        }, duration / steps);
    });
    
    // Setup achievement cards hover effect
    const achievementCards = document.querySelectorAll('.achievement-card');
    
    achievementCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.classList.add('achievement-hover');
        });
        
        card.addEventListener('mouseleave', function() {
            this.classList.remove('achievement-hover');
        });
    });
}

// Setup language selector
function setupLanguageSelector() {
    const languageSelector = document.getElementById('language-selector');
    
    if (languageSelector) {
        languageSelector.addEventListener('change', function() {
            const language = this.value;
            
            // Update user's preferred language
            fetch('/api/update_language', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `language=${language}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Reload page to reflect language change
                    window.location.reload();
                }
            })
            .catch(error => {
                console.error('Error updating language:', error);
            });
        });
    }
}

// Setup accessibility features
function setupAccessibility() {
    const textSizeButtons = document.querySelectorAll('.text-size-btn');
    
    textSizeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const action = this.getAttribute('data-action');
            const root = document.documentElement;
            
            // Get current font size
            let currentSize = parseInt(getComputedStyle(root).fontSize, 10);
            
            // Adjust font size
            if (action === 'increase') {
                currentSize += 2;
            } else if (action === 'decrease') {
                currentSize = Math.max(12, currentSize - 2);
            } else if (action === 'reset') {
                currentSize = 16;
            }
            
            // Apply new font size
            root.style.fontSize = `${currentSize}px`;
            
            // Store preference in localStorage
            localStorage.setItem('preferredFontSize', currentSize);
        });
    });
    
    // Apply stored font size preference
    const storedFontSize = localStorage.getItem('preferredFontSize');
    if (storedFontSize) {
        document.documentElement.style.fontSize = `${storedFontSize}px`;
    }
    
    // High contrast toggle
    const contrastToggle = document.getElementById('contrast-toggle');
    
    if (contrastToggle) {
        contrastToggle.addEventListener('change', function() {
            if (this.checked) {
                document.body.classList.add('high-contrast');
                localStorage.setItem('highContrast', 'true');
            } else {
                document.body.classList.remove('high-contrast');
                localStorage.setItem('highContrast', 'false');
            }
        });
        
        // Apply stored contrast preference
        if (localStorage.getItem('highContrast') === 'true') {
            contrastToggle.checked = true;
            document.body.classList.add('high-contrast');
        }
    }
}

// Function to handle form submission with validation
function validateForm(formId, validationRules) {
    const form = document.getElementById(formId);
    
    if (!form) return;
    
    form.addEventListener('submit', function(event) {
        let isValid = true;
        
        // Check each validation rule
        for (const fieldId in validationRules) {
            const field = document.getElementById(fieldId);
            const errorElement = document.getElementById(`${fieldId}-error`);
            
            if (!field || !errorElement) continue;
            
            const value = field.value.trim();
            const rules = validationRules[fieldId];
            
            // Clear previous error
            errorElement.textContent = '';
            field.classList.remove('is-invalid');
            
            // Check required
            if (rules.required && value === '') {
                errorElement.textContent = rules.requiredMessage || 'This field is required';
                field.classList.add('is-invalid');
                isValid = false;
                continue;
            }
            
            // Check minimum length
            if (rules.minLength && value.length < rules.minLength) {
                errorElement.textContent = `Must be at least ${rules.minLength} characters`;
                field.classList.add('is-invalid');
                isValid = false;
                continue;
            }
            
            // Check pattern
            if (rules.pattern && !rules.pattern.test(value)) {
                errorElement.textContent = rules.patternMessage || 'Invalid format';
                field.classList.add('is-invalid');
                isValid = false;
                continue;
            }
            
            // Check custom validation
            if (rules.validate && typeof rules.validate === 'function') {
                const customError = rules.validate(value);
                if (customError) {
                    errorElement.textContent = customError;
                    field.classList.add('is-invalid');
                    isValid = false;
                    continue;
                }
            }
        }
        
        if (!isValid) {
            event.preventDefault();
        }
    });
}

// Show a feedback toast message
function showToast(message, type = 'success') {
    const toastContainer = document.getElementById('toast-container');
    
    if (!toastContainer) {
        console.error('Toast container not found');
        return;
    }
    
    // Create toast element
    const toastElement = document.createElement('div');
    toastElement.className = `toast align-items-center text-white bg-${type} border-0`;
    toastElement.setAttribute('role', 'alert');
    toastElement.setAttribute('aria-live', 'assertive');
    toastElement.setAttribute('aria-atomic', 'true');
    
    // Create toast content
    toastElement.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    // Add toast to container
    toastContainer.appendChild(toastElement);
    
    // Initialize and show toast
    const toast = new bootstrap.Toast(toastElement, {
        autohide: true,
        delay: 5000
    });
    toast.show();
    
    // Remove toast after it's hidden
    toastElement.addEventListener('hidden.bs.toast', function() {
        toastElement.remove();
    });
}
