// Voice-based navigation and interaction for VidyAI++

// Global variables
let speechRecognition = null;
let speechSynthesis = window.speechSynthesis;
let recognitionActive = false;
let voiceCommandsEnabled = false;
let preferredVoice = null;
let preferredLanguage = 'en-US';

// Initialize voice features when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Set preferred language if specified in user profile
    const langElement = document.querySelector('html[lang]');
    if (langElement) {
        const lang = langElement.getAttribute('lang');
        setPreferredLanguage(lang);
    }
    
    // Initialize voice navigation if element exists
    const voiceNavBtn = document.getElementById('voice-nav-button');
    const voiceOutput = document.getElementById('voice-output');
    
    if (voiceNavBtn) {
        // Check if browser supports speech recognition
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            voiceNavBtn.disabled = true;
            voiceNavBtn.title = 'Voice navigation not supported in this browser';
            return;
        }
        
        // Setup voice navigation button
        voiceNavBtn.addEventListener('click', function() {
            if (recognitionActive) {
                stopSpeechRecognition();
                this.innerHTML = '<i class="bi bi-mic"></i> Start Voice';
                this.classList.remove('btn-danger');
                this.classList.add('btn-primary');
            } else {
                startSpeechRecognition();
                this.innerHTML = '<i class="bi bi-mic-mute"></i> Stop Voice';
                this.classList.remove('btn-primary');
                this.classList.add('btn-danger');
            }
        });
        
        // Auto-start if specified
        if (voiceNavBtn.getAttribute('data-auto-start') === 'true') {
            voiceNavBtn.click();
        }
    }
    
    // Setup text-to-speech for elements with data-speak attribute
    setupTextToSpeech();
    
    // Setup voice commands
    setupVoiceCommands();
});

// Set preferred language for speech recognition and synthesis
function setPreferredLanguage(lang) {
    // Map HTML lang attribute to speech recognition language code
    const langMap = {
        'en': 'en-US',
        'hi': 'hi-IN',
        'bn': 'bn-IN',
        'ta': 'ta-IN',
        'te': 'te-IN',
        'mr': 'mr-IN'
    };
    
    preferredLanguage = langMap[lang] || 'en-US';
    
    // Also find suitable voice for this language
    if (speechSynthesis) {
        const voices = speechSynthesis.getVoices();
        preferredVoice = voices.find(voice => voice.lang.startsWith(lang)) || null;
    }
}

// Start speech recognition
function startSpeechRecognition() {
    if (recognitionActive) return;
    
    // Create speech recognition object
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    speechRecognition = new SpeechRecognition();
    
    // Configure recognition
    speechRecognition.continuous = false;
    speechRecognition.interimResults = false;
    speechRecognition.lang = preferredLanguage;
    
    // Setup recognition events
    speechRecognition.onstart = function() {
        recognitionActive = true;
        console.log('Speech recognition started');
        
        // Show listening indicator
        const indicator = document.getElementById('voice-indicator');
        if (indicator) {
            indicator.classList.remove('d-none');
        }
    };
    
    speechRecognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript.trim();
        console.log('Recognized speech:', transcript);
        
        // Show recognized text
        const voiceOutput = document.getElementById('voice-output');
        if (voiceOutput) {
            voiceOutput.textContent = `"${transcript}"`;
            voiceOutput.classList.remove('d-none');
        }
        
        // Process voice command
        processVoiceCommand(transcript);
    };
    
    speechRecognition.onerror = function(event) {
        console.error('Speech recognition error:', event.error);
        
        // Show error
        const voiceOutput = document.getElementById('voice-output');
        if (voiceOutput) {
            voiceOutput.textContent = `Error: ${event.error}`;
            voiceOutput.classList.remove('d-none');
        }
    };
    
    speechRecognition.onend = function() {
        recognitionActive = false;
        console.log('Speech recognition ended');
        
        // Hide listening indicator
        const indicator = document.getElementById('voice-indicator');
        if (indicator) {
            indicator.classList.add('d-none');
        }
        
        // Restart recognition if continuous listening is enabled
        if (voiceCommandsEnabled) {
            setTimeout(() => {
                startSpeechRecognition();
            }, 1000);
        }
    };
    
    // Start recognition
    speechRecognition.start();
}

// Stop speech recognition
function stopSpeechRecognition() {
    if (!recognitionActive || !speechRecognition) return;
    
    voiceCommandsEnabled = false;
    speechRecognition.stop();
    recognitionActive = false;
    
    console.log('Speech recognition stopped');
}

// Process voice command
function processVoiceCommand(command) {
    // Send command to server for processing
    fetch('/api/voice_command', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ command: command })
    })
    .then(response => response.json())
    .then(data => {
        console.log('Voice command response:', data);
        
        // Handle different action types
        if (data.action === 'navigate') {
            // Speak feedback before navigating
            speakText(`Navigating to ${data.url.split('/').pop()}`);
            
            // Navigate after a short delay
            setTimeout(() => {
                window.location.href = data.url;
            }, 1500);
        } else if (data.action === 'speak') {
            speakText(data.message);
        } else if (data.action === 'execute') {
            // Execute a function
            if (data.function && window[data.function]) {
                window[data.function](...(data.params || []));
            }
        }
    })
    .catch(error => {
        console.error('Error processing voice command:', error);
        
        // Try to handle some commands locally if server is unavailable
        processLocalVoiceCommand(command);
    });
}

// Process voice command locally (for offline mode)
function processLocalVoiceCommand(command) {
    command = command.toLowerCase();
    
    // Basic navigation commands
    if (command.includes('go home') || command.includes('home page')) {
        speakText('Going to home page');
        setTimeout(() => { window.location.href = '/'; }, 1500);
    } else if (command.includes('dashboard')) {
        speakText('Going to dashboard');
        setTimeout(() => { window.location.href = '/dashboard'; }, 1500);
    } else if (command.includes('learn')) {
        speakText('Going to learning page');
        setTimeout(() => { window.location.href = '/learn'; }, 1500);
    } else if (command.includes('assessment')) {
        speakText('Going to assessment page');
        setTimeout(() => { window.location.href = '/assessment'; }, 1500);
    } else if (command.includes('mentors')) {
        speakText('Going to mentors page');
        setTimeout(() => { window.location.href = '/mentors'; }, 1500);
    } else if (command.includes('profile')) {
        speakText('Going to profile page');
        setTimeout(() => { window.location.href = '/profile'; }, 1500);
    } else if (command.includes('logout') || command.includes('sign out')) {
        speakText('Logging out');
        setTimeout(() => { window.location.href = '/logout'; }, 1500);
    } 
    // UI interaction commands
    else if (command.includes('increase text') || command.includes('bigger text')) {
        const increaseBtn = document.querySelector('.text-size-btn[data-action="increase"]');
        if (increaseBtn) {
            increaseBtn.click();
            speakText('Increased text size');
        }
    } else if (command.includes('decrease text') || command.includes('smaller text')) {
        const decreaseBtn = document.querySelector('.text-size-btn[data-action="decrease"]');
        if (decreaseBtn) {
            decreaseBtn.click();
            speakText('Decreased text size');
        }
    } else if (command.includes('reset text')) {
        const resetBtn = document.querySelector('.text-size-btn[data-action="reset"]');
        if (resetBtn) {
            resetBtn.click();
            speakText('Reset text size');
        }
    } 
    // Read content
    else if (command.includes('read page') || command.includes('read content')) {
        const mainContent = document.querySelector('main p');
        if (mainContent) {
            speakText(mainContent.textContent);
        } else {
            speakText('No content to read');
        }
    } else {
        speakText('I did not understand that command');
    }
}

// Setup text-to-speech for elements with data-speak attribute
function setupTextToSpeech() {
    const speakElements = document.querySelectorAll('[data-speak]');
    
    speakElements.forEach(element => {
        // Add speak icon
        const speakIcon = document.createElement('button');
        speakIcon.className = 'btn btn-sm btn-outline-info ms-2 speak-button';
        speakIcon.innerHTML = '<i class="bi bi-volume-up"></i>';
        speakIcon.title = 'Click to hear this text';
        
        // Add speak functionality
        speakIcon.addEventListener('click', function(event) {
            event.preventDefault();
            event.stopPropagation();
            
            const textToSpeak = element.getAttribute('data-speak') || element.textContent;
            speakText(textToSpeak);
        });
        
        // Add icon to element
        element.appendChild(speakIcon);
    });
}

// Setup voice commands
function setupVoiceCommands() {
    const voiceCommandsToggle = document.getElementById('voice-commands-toggle');
    
    if (voiceCommandsToggle) {
        voiceCommandsToggle.addEventListener('change', function() {
            voiceCommandsEnabled = this.checked;
            
            if (this.checked) {
                // Enable continuous voice commands
                if (!recognitionActive) {
                    startSpeechRecognition();
                    
                    // Update UI if voice button exists
                    const voiceNavBtn = document.getElementById('voice-nav-button');
                    if (voiceNavBtn) {
                        voiceNavBtn.innerHTML = '<i class="bi bi-mic-mute"></i> Stop Voice';
                        voiceNavBtn.classList.remove('btn-primary');
                        voiceNavBtn.classList.add('btn-danger');
                    }
                }
                
                speakText('Voice commands enabled');
            } else {
                // Voice commands will be disabled when recognition ends
                speakText('Voice commands disabled');
            }
        });
    }
}

// Speak text using text-to-speech
function speakText(text) {
    if (!speechSynthesis) return;
    
    // Cancel any current speech
    speechSynthesis.cancel();
    
    // Create utterance
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Set language and voice
    utterance.lang = preferredLanguage;
    if (preferredVoice) {
        utterance.voice = preferredVoice;
    }
    
    // Speak the text
    speechSynthesis.speak(utterance);
}

// Show available voice commands
function showVoiceCommands() {
    // Create modal if it doesn't exist
    let modal = document.getElementById('voice-commands-modal');
    
    if (!modal) {
        modal = document.createElement('div');
        modal.className = 'modal fade';
        modal.id = 'voice-commands-modal';
        modal.setAttribute('tabindex', '-1');
        modal.setAttribute('aria-labelledby', 'voice-commands-modal-label');
        modal.setAttribute('aria-hidden', 'true');
        
        const modalContent = `
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="voice-commands-modal-label">Available Voice Commands</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Navigation Commands</h6>
                                <ul class="list-group">
                                    <li class="list-group-item">"Go Home" or "Home Page"</li>
                                    <li class="list-group-item">"Go to Dashboard"</li>
                                    <li class="list-group-item">"Go to Learn"</li>
                                    <li class="list-group-item">"Go to Assessment"</li>
                                    <li class="list-group-item">"Go to Mentors"</li>
                                    <li class="list-group-item">"Go to Profile"</li>
                                    <li class="list-group-item">"Logout" or "Sign out"</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h6>Interaction Commands</h6>
                                <ul class="list-group">
                                    <li class="list-group-item">"Increase text size" or "Bigger text"</li>
                                    <li class="list-group-item">"Decrease text size" or "Smaller text"</li>
                                    <li class="list-group-item">"Reset text size"</li>
                                    <li class="list-group-item">"Read page" or "Read content"</li>
                                    <li class="list-group-item">"Show commands" or "Help"</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        `;
        
        modal.innerHTML = modalContent;
        document.body.appendChild(modal);
    }
    
    // Show the modal
    const modalInstance = new bootstrap.Modal(modal);
    modalInstance.show();
}
