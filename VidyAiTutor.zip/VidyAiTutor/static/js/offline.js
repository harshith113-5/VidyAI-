// Offline functionality for VidyAI++

// Global variables for offline data management
let offlineDatabase = null;
const DB_NAME = 'vidyai_offline';
const DB_VERSION = 1;
const CONTENT_STORE = 'learning_content';
const ACTIVITY_STORE = 'learning_activities';
const SYNC_STORE = 'sync_queue';

// Initialize offline functionality when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Initialize IndexedDB
    initOfflineDatabase();
    
    // Setup offline content caching
    setupOfflineContent();
    
    // Setup sync functionality for when online
    setupSyncFunctionality();
});

// Initialize IndexedDB for offline storage
function initOfflineDatabase() {
    if (!window.indexedDB) {
        console.error('Your browser does not support IndexedDB. Offline features will not work.');
        return;
    }
    
    // Open database
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    
    request.onerror = function(event) {
        console.error('Error opening offline database:', event.target.error);
    };
    
    request.onsuccess = function(event) {
        offlineDatabase = event.target.result;
        console.log('Offline database initialized');
        
        // Check for offline content after DB is ready
        checkOfflineContent();
    };
    
    request.onupgradeneeded = function(event) {
        const db = event.target.result;
        
        // Create object stores if they don't exist
        if (!db.objectStoreNames.contains(CONTENT_STORE)) {
            const contentStore = db.createObjectStore(CONTENT_STORE, { keyPath: 'id' });
            contentStore.createIndex('subject', 'subject', { unique: false });
            contentStore.createIndex('difficulty', 'difficulty_level', { unique: false });
            contentStore.createIndex('language', 'language', { unique: false });
        }
        
        if (!db.objectStoreNames.contains(ACTIVITY_STORE)) {
            const activityStore = db.createObjectStore(ACTIVITY_STORE, { keyPath: 'local_id', autoIncrement: true });
            activityStore.createIndex('user_id', 'user_id', { unique: false });
            activityStore.createIndex('content_id', 'content_id', { unique: false });
            activityStore.createIndex('synced', 'synced', { unique: false });
        }
        
        if (!db.objectStoreNames.contains(SYNC_STORE)) {
            const syncStore = db.createObjectStore(SYNC_STORE, { keyPath: 'id', autoIncrement: true });
            syncStore.createIndex('type', 'type', { unique: false });
            syncStore.createIndex('timestamp', 'timestamp', { unique: false });
        }
    };
}

// Setup offline content caching
function setupOfflineContent() {
    // Add event listeners to cache buttons
    const cacheButtons = document.querySelectorAll('.cache-offline-btn');
    
    cacheButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            
            const contentId = this.getAttribute('data-content-id');
            cacheContentForOffline(contentId);
        });
    });
}

// Cache content for offline use
function cacheContentForOffline(contentId) {
    if (!offlineDatabase) {
        showToast('Offline database not available', 'error');
        return;
    }
    
    // First check if already cached
    const transaction = offlineDatabase.transaction([CONTENT_STORE], 'readonly');
    const store = transaction.objectStore(CONTENT_STORE);
    const request = store.get(parseInt(contentId, 10));
    
    request.onsuccess = function(event) {
        if (event.target.result) {
            showToast('Content already available offline', 'info');
            updateCacheButton(contentId, true);
            return;
        }
        
        // Content not cached, fetch it
        fetch(`/api/get_content/${contentId}`)
            .then(response => response.json())
            .then(content => {
                // Store in IndexedDB
                const transaction = offlineDatabase.transaction([CONTENT_STORE], 'readwrite');
                const store = transaction.objectStore(CONTENT_STORE);
                store.put(content);
                
                transaction.oncomplete = function() {
                    showToast('Content saved for offline use', 'success');
                    updateCacheButton(contentId, true);
                    
                    // Also cache resources if available
                    if (content.resources) {
                        cacheResources(content.resources);
                    }
                };
                
                transaction.onerror = function(error) {
                    console.error('Error caching content:', error);
                    showToast('Failed to save content offline', 'error');
                };
            })
            .catch(error => {
                console.error('Error fetching content:', error);
                showToast('Failed to download content', 'error');
            });
    };
}

// Update cache button status
function updateCacheButton(contentId, isCached) {
    const button = document.querySelector(`.cache-offline-btn[data-content-id="${contentId}"]`);
    
    if (!button) return;
    
    if (isCached) {
        button.innerHTML = '<i class="bi bi-check-circle-fill"></i> Available Offline';
        button.classList.remove('btn-outline-primary');
        button.classList.add('btn-success');
        button.disabled = true;
    } else {
        button.innerHTML = '<i class="bi bi-download"></i> Save for Offline';
        button.classList.remove('btn-success');
        button.classList.add('btn-outline-primary');
        button.disabled = false;
    }
}

// Cache additional resources (images, documents, etc.)
function cacheResources(resources) {
    if (!('caches' in window)) {
        console.log('Cache API not available');
        return;
    }
    
    // Open a cache
    caches.open('vidyai-resources').then(cache => {
        // Add resources to cache
        cache.addAll(resources)
            .then(() => {
                console.log('Resources cached successfully');
            })
            .catch(error => {
                console.error('Error caching resources:', error);
            });
    });
}

// Check for offline content
function checkOfflineContent() {
    if (!offlineDatabase) return;
    
    // Get all content items
    const contentItems = document.querySelectorAll('[data-content-id]');
    
    if (contentItems.length === 0) return;
    
    // Check each content item
    const transaction = offlineDatabase.transaction([CONTENT_STORE], 'readonly');
    const store = transaction.objectStore(CONTENT_STORE);
    
    contentItems.forEach(item => {
        const contentId = item.getAttribute('data-content-id');
        const request = store.get(parseInt(contentId, 10));
        
        request.onsuccess = function(event) {
            if (event.target.result) {
                // Content is available offline, update UI
                const button = item.querySelector('.cache-offline-btn');
                if (button) {
                    updateCacheButton(contentId, true);
                }
                
                // Add offline indicator
                if (!item.querySelector('.offline-badge')) {
                    const badge = document.createElement('span');
                    badge.className = 'badge bg-success offline-badge ms-2';
                    badge.innerHTML = '<i class="bi bi-wifi-off"></i> Offline';
                    
                    const title = item.querySelector('.content-title');
                    if (title) {
                        title.appendChild(badge);
                    }
                }
            }
        };
    });
}

// Store completion data for offline use
function storeOfflineCompletion(contentId, score) {
    if (!offlineDatabase) return;
    
    // Create activity record
    const activity = {
        user_id: getCurrentUserId(),
        content_id: parseInt(contentId, 10),
        start_time: new Date().toISOString(),
        end_time: new Date().toISOString(),
        completed: true,
        score: parseFloat(score),
        synced: false
    };
    
    // Store in IndexedDB
    const transaction = offlineDatabase.transaction([ACTIVITY_STORE], 'readwrite');
    const store = transaction.objectStore(ACTIVITY_STORE);
    store.add(activity);
    
    // Also add to sync queue
    const syncTransaction = offlineDatabase.transaction([SYNC_STORE], 'readwrite');
    const syncStore = syncTransaction.objectStore(SYNC_STORE);
    syncStore.add({
        type: 'activity_completion',
        data: activity,
        timestamp: new Date().toISOString()
    });
    
    transaction.oncomplete = function() {
        console.log('Offline activity stored successfully');
    };
    
    transaction.onerror = function(error) {
        console.error('Error storing offline activity:', error);
    };
}

// Get current user ID from page data
function getCurrentUserId() {
    const userElement = document.getElementById('current-user-data');
    
    if (userElement) {
        return parseInt(userElement.getAttribute('data-user-id'), 10);
    }
    
    return 0; // Default if not found
}

// Setup sync functionality for when online
function setupSyncFunctionality() {
    window.addEventListener('online', syncOfflineData);
}

// Sync offline data when online
function syncOfflineData() {
    if (!offlineDatabase || !navigator.onLine) return;
    
    console.log('Syncing offline data...');
    
    // Get all unsynchronized activity data
    const transaction = offlineDatabase.transaction([ACTIVITY_STORE], 'readonly');
    const store = transaction.objectStore(ACTIVITY_STORE);
    const unsyncedIndex = store.index('synced');
    const request = unsyncedIndex.getAll(false);
    
    request.onsuccess = function(event) {
        const activities = event.target.result;
        
        if (activities.length === 0) {
            console.log('No offline activities to sync');
            return;
        }
        
        console.log(`Syncing ${activities.length} activities`);
        
        // Sync each activity
        activities.forEach(activity => {
            syncActivity(activity);
        });
    };
    
    request.onerror = function(error) {
        console.error('Error getting unsynced activities:', error);
    };
}

// Sync a single activity
function syncActivity(activity) {
    fetch('/complete_activity', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `score=${activity.score}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Mark as synced
            const transaction = offlineDatabase.transaction([ACTIVITY_STORE], 'readwrite');
            const store = transaction.objectStore(ACTIVITY_STORE);
            
            activity.synced = true;
            store.put(activity);
            
            console.log(`Activity ${activity.local_id} synced successfully`);
        }
    })
    .catch(error => {
        console.error('Error syncing activity:', error);
    });
}

// Load offline content when in offline mode
function loadOfflineContent() {
    if (!offlineDatabase) return;
    
    const contentContainer = document.getElementById('offline-content-container');
    
    if (!contentContainer) return;
    
    // Clear container
    contentContainer.innerHTML = '<h3>Your Offline Content</h3>';
    
    // Get all cached content
    const transaction = offlineDatabase.transaction([CONTENT_STORE], 'readonly');
    const store = transaction.objectStore(CONTENT_STORE);
    const request = store.getAll();
    
    request.onsuccess = function(event) {
        const content = event.target.result;
        
        if (content.length === 0) {
            contentContainer.innerHTML += '<p>No content available offline. Connect to the internet and save content for offline use.</p>';
            return;
        }
        
        // Create content cards
        const contentList = document.createElement('div');
        contentList.className = 'row row-cols-1 row-cols-md-2 g-4 mt-3';
        
        content.forEach(item => {
            const card = createContentCard(item);
            contentList.appendChild(card);
        });
        
        contentContainer.appendChild(contentList);
    };
    
    request.onerror = function(error) {
        console.error('Error loading offline content:', error);
        contentContainer.innerHTML += '<p>Error loading offline content. Please try again.</p>';
    };
}

// Create a content card for offline content
function createContentCard(content) {
    const col = document.createElement('div');
    col.className = 'col';
    
    col.innerHTML = `
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">${content.title}</h5>
                <span class="badge bg-success"><i class="bi bi-wifi-off"></i> Offline</span>
            </div>
            <div class="card-body">
                <p class="card-text">${content.description}</p>
                <div class="d-flex justify-content-between">
                    <span class="badge bg-info">${content.subject}</span>
                    <span class="badge bg-secondary">Difficulty: ${content.difficulty_level}/5</span>
                </div>
            </div>
            <div class="card-footer">
                <a href="/learn/${content.id}" class="btn btn-primary">Start Learning</a>
            </div>
        </div>
    `;
    
    return col;
}
