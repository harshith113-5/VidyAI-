import os
import json
import logging
from openai import OpenAI

# Initialize OpenAI client
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
openai = OpenAI(api_key=OPENAI_API_KEY)

def translate_content(content, source_language, target_language):
    """
    Translate content from source language to target language
    """
    try:
        if source_language == target_language:
            return content
        
        # Parse content if it's a JSON string
        is_json = False
        try:
            content_obj = json.loads(content)
            is_json = True
        except:
            content_obj = content
        
        # Prepare prompt for translation
        system_prompt = f"""
        You are VidyAI++, an advanced educational content translator.
        Translate the content from {source_language} to {target_language}.
        Maintain the educational value, clarity, and original structure of the content.
        Ensure that the translation is culturally appropriate and uses age-appropriate terminology.
        """
        
        if is_json:
            # For JSON content, we need to structure the prompt differently
            prompt = f"Translate the following educational content from {source_language} to {target_language}. Keep the JSON structure intact:\n\n{content}"
        else:
            prompt = f"Translate the following educational content from {source_language} to {target_language}:\n\n{content}"
        
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1500
        )
        
        translated_content = response.choices[0].message.content
        
        # If the original was JSON, ensure the translation is valid JSON
        if is_json:
            try:
                json.loads(translated_content)
            except:
                # If translation resulted in invalid JSON, try to fix it
                fix_prompt = f"The previous translation resulted in invalid JSON. Please fix the JSON structure while maintaining the translated content in {target_language}:\n\n{translated_content}"
                
                # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
                # do not change this unless explicitly requested by the user
                fix_response = openai.chat.completions.create(
                    model="gpt-4o",
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": fix_prompt}
                    ],
                    response_format={"type": "json_object"},
                    max_tokens=1500
                )
                
                translated_content = fix_response.choices[0].message.content
        
        return translated_content
        
    except Exception as e:
        logging.error(f"Error translating content: {str(e)}")
        return content  # Return original content if translation fails

def detect_language(text):
    """
    Detect the language of the given text
    """
    try:
        system_prompt = """
        You are a language detection expert. Identify the language of the given text.
        Respond with only the language name in lowercase (e.g., "english", "hindi", "tamil").
        """
        
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Detect the language of this text:\n\n{text[:500]}"}
            ],
            max_tokens=50
        )
        
        detected_language = response.choices[0].message.content.strip().lower()
        
        # Map to our supported languages
        language_map = {
            'english': 'english',
            'hindi': 'hindi',
            'bengali': 'bengali',
            'tamil': 'tamil',
            'telugu': 'telugu',
            'marathi': 'marathi'
        }
        
        return language_map.get(detected_language, 'english')
        
    except Exception as e:
        logging.error(f"Error detecting language: {str(e)}")
        return 'english'  # Default to English if detection fails

def get_voice_response(text, language='english'):
    """
    Generate voice response text suitable for text-to-speech
    """
    try:
        system_prompt = f"""
        You are VidyAI++, a friendly educational assistant.
        Create a natural-sounding voice response in {language} that is concise and clear.
        Keep the response short and direct, suitable for text-to-speech conversion.
        Use simple sentence structures and avoid complex vocabulary.
        """
        
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": text}
            ],
            max_tokens=200
        )
        
        return response.choices[0].message.content
        
    except Exception as e:
        logging.error(f"Error generating voice response: {str(e)}")
        return text  # Return original text if generation fails
