import logging
from datetime import datetime, timedelta
from models import StudentProfile, Achievement, LearningStyle, LearningActivity
from app import db

def assess_learning_style(answers):
    """
    Assess learning style based on assessment answers
    Returns scores for visual, auditory, and kinesthetic learning styles
    """
    try:
        # Initialize scores
        visual_score = 0
        auditory_score = 0
        kinesthetic_score = 0
        
        # Count the number of questions for each category
        visual_count = 0
        auditory_count = 0
        kinesthetic_count = 0
        
        # Process each answer
        for question_id, answer in answers.items():
            # Check question category from the question ID
            category = question_id.split('_')[0]
            
            # Convert answer to a numeric value (assuming 1-5 scale)
            value = int(answer)
            
            # Update corresponding score
            if category == 'visual':
                visual_score += value
                visual_count += 1
            elif category == 'auditory':
                auditory_score += value
                auditory_count += 1
            elif category == 'kinesthetic':
                kinesthetic_score += value
                kinesthetic_count += 1
        
        # Calculate average scores
        if visual_count > 0:
            visual_score = visual_score / visual_count
        if auditory_count > 0:
            auditory_score = auditory_score / auditory_count
        if kinesthetic_count > 0:
            kinesthetic_score = kinesthetic_score / kinesthetic_count
        
        return visual_score, auditory_score, kinesthetic_score
        
    except Exception as e:
        logging.error(f"Error assessing learning style: {str(e)}")
        return 3.0, 3.0, 3.0  # Return neutral scores if assessment fails

def update_student_progress(user_id, activity):
    """
    Update student progress based on completed learning activity
    Check for achievements and update streak
    """
    try:
        student_profile = StudentProfile.query.filter_by(user_id=user_id).first()
        
        if not student_profile:
            return
        
        # Update last active time
        student_profile.last_active = datetime.utcnow()
        
        # Check if this was the first activity today
        today = datetime.utcnow().date()
        activities_today = LearningActivity.query.filter(
            LearningActivity.user_id == user_id,
            LearningActivity.completed == True,
            db.func.date(LearningActivity.end_time) == today
        ).count()
        
        if activities_today == 1:
            # This is the first activity today, check if streak should be updated
            yesterday = today - timedelta(days=1)
            activities_yesterday = LearningActivity.query.filter(
                LearningActivity.user_id == user_id,
                LearningActivity.completed == True,
                db.func.date(LearningActivity.end_time) == yesterday
            ).count()
            
            if activities_yesterday > 0 or student_profile.streak_days == 0:
                # Either continued streak or starting a new streak
                student_profile.streak_days += 1
                
                # Check for streak achievements
                if student_profile.streak_days == 3:
                    award_achievement(user_id, "3-Day Streak", "Completed learning activities for 3 days in a row!", "streak_bronze", 50)
                elif student_profile.streak_days == 7:
                    award_achievement(user_id, "7-Day Streak", "Completed learning activities for a whole week!", "streak_silver", 100)
                elif student_profile.streak_days == 30:
                    award_achievement(user_id, "30-Day Streak", "Completed learning activities for a whole month!", "streak_gold", 500)
        
        # Award points for completing activity
        if activity.score:
            points_earned = int(activity.score * 10)  # 10 points per activity, scaled by score
        else:
            points_earned = 5  # Default points
            
        student_profile.points += points_earned
        
        # Check for activity completion milestones
        total_completed = LearningActivity.query.filter_by(
            user_id=user_id,
            completed=True
        ).count()
        
        if total_completed == 1:
            award_achievement(user_id, "First Steps", "Completed your first learning activity!", "first_activity", 10)
        elif total_completed == 10:
            award_achievement(user_id, "Eager Learner", "Completed 10 learning activities!", "ten_activities", 100)
        elif total_completed == 50:
            award_achievement(user_id, "Knowledge Seeker", "Completed 50 learning activities!", "fifty_activities", 250)
        
        # Check for points milestones
        if student_profile.points >= 100 and student_profile.points - points_earned < 100:
            award_achievement(user_id, "Century", "Earned 100 points!", "points_100", 20)
        elif student_profile.points >= 500 and student_profile.points - points_earned < 500:
            award_achievement(user_id, "Scholar", "Earned 500 points!", "points_500", 50)
        elif student_profile.points >= 1000 and student_profile.points - points_earned < 1000:
            award_achievement(user_id, "Academic Star", "Earned 1000 points!", "points_1000", 100)
        
        db.session.commit()
        
    except Exception as e:
        logging.error(f"Error updating student progress: {str(e)}")
        db.session.rollback()

def award_achievement(user_id, title, description, badge_name, points_awarded):
    """
    Award an achievement to a student
    """
    try:
        # Check if the achievement already exists
        existing = Achievement.query.filter_by(
            user_id=user_id,
            title=title
        ).first()
        
        if existing:
            return  # Don't award the same achievement twice
        
        # Create new achievement
        achievement = Achievement(
            user_id=user_id,
            title=title,
            description=description,
            badge_name=badge_name,
            points_awarded=points_awarded
        )
        
        db.session.add(achievement)
        
        # Add points to student profile
        student_profile = StudentProfile.query.filter_by(user_id=user_id).first()
        if student_profile:
            student_profile.points += points_awarded
        
        db.session.commit()
        
    except Exception as e:
        logging.error(f"Error awarding achievement: {str(e)}")
        db.session.rollback()

def calculate_streak(user_id):
    """
    Calculate current streak days
    """
    try:
        student_profile = StudentProfile.query.filter_by(user_id=user_id).first()
        
        if not student_profile:
            return 0
        
        return student_profile.streak_days
        
    except Exception as e:
        logging.error(f"Error calculating streak: {str(e)}")
        return 0

def get_learning_recommendations(user_id):
    """
    Get personalized learning recommendations
    """
    try:
        student_profile = StudentProfile.query.filter_by(user_id=user_id).first()
        
        if not student_profile:
            return []
        
        # Get learning style
        learning_style = student_profile.learning_style
        
        # Default recommendations
        recommendations = {
            LearningStyle.VISUAL: [
                "Try using diagrams and charts to visualize concepts",
                "Watch educational videos on the topic",
                "Create mind maps to organize information"
            ],
            LearningStyle.AUDITORY: [
                "Listen to educational podcasts or audiobooks",
                "Explain concepts aloud to yourself",
                "Join discussion groups to talk about the topic"
            ],
            LearningStyle.KINESTHETIC: [
                "Use hands-on activities and practical exercises",
                "Take short breaks for physical movement",
                "Create physical models or act out concepts"
            ],
            LearningStyle.UNKNOWN: [
                "Try different learning approaches to find what works best",
                "Complete the learning style assessment",
                "Combine visual, auditory, and hands-on activities"
            ]
        }
        
        return recommendations.get(learning_style, recommendations[LearningStyle.UNKNOWN])
        
    except Exception as e:
        logging.error(f"Error getting learning recommendations: {str(e)}")
        return [
            "Complete activities regularly to build a learning streak",
            "Try different subjects to discover your interests",
            "Take breaks between learning sessions"
        ]
