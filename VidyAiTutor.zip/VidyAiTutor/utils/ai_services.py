import os
import json
import logging
from datetime import datetime
from openai import OpenAI
from models import User, StudentProfile, LearningContent, LearningActivity

# Initialize OpenAI client
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
openai = OpenAI(api_key=OPENAI_API_KEY)

def generate_personalized_content(topic, subject, difficulty, learning_style, language, grade_level):
    """
    Generate personalized learning content using OpenAI API
    """
    try:
        # Construct the prompt
        system_prompt = f"""
        You are VidyAI++, an advanced educational AI tutor specializing in creating personalized learning content for students.
        Create educational content for a grade {grade_level} student with a {learning_style} learning style.
        The content should be on the topic of "{topic}" in the subject area of "{subject}".
        Set the difficulty level to {difficulty} (on a scale of 1-5).
        Present the content in {language} language.
        
        Structure your response as a JSON object with the following fields:
        - title: A catchy title for the content
        - introduction: A brief introduction to the topic
        - content: The main educational content, formatted appropriately for the student's learning style
        - summary: A concise summary of the key points
        - questions: 3-5 practice questions to test understanding
        - activities: 2-3 suggested activities aligned with the student's learning style
        
        Ensure that the content is engaging, accurate, and appropriate for the student's grade level.
        """
        
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Generate educational content about {topic} in {subject}"}
            ],
            response_format={"type": "json_object"},
            max_tokens=1500
        )
        
        content_data = json.loads(response.choices[0].message.content)
        
        # Create a new content entry in the database
        learning_content = LearningContent(
            title=content_data["title"],
            description=content_data["introduction"],
            content_type="text",
            difficulty_level=difficulty,
            subject=subject,
            language=language,
            content=json.dumps(content_data),
            prerequisites="",
            learning_outcomes=""
        )
        
        from app import db
        db.session.add(learning_content)
        db.session.commit()
        
        # Return the generated content with the database ID
        content_data["id"] = learning_content.id
        return content_data
        
    except Exception as e:
        logging.error(f"Error generating content: {str(e)}")
        raise

def analyze_student_response(question, student_answer, grade_level):
    """
    Analyze a student's response to a question using OpenAI API
    """
    try:
        system_prompt = f"""
        You are VidyAI++, an advanced educational AI tutor. Analyze the student's answer to the given question.
        The student is in grade {grade_level}.
        
        Provide your analysis as a JSON object with the following fields:
        - correct: Boolean indicating if the answer is correct
        - score: A score from 0 to 1
        - feedback: Constructive feedback for the student
        - explanation: A detailed explanation of the correct answer
        - improvement_tips: Specific tips to help the student improve
        """
        
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Question: {question}\nStudent's Answer: {student_answer}"}
            ],
            response_format={"type": "json_object"},
            max_tokens=800
        )
        
        return json.loads(response.choices[0].message.content)
        
    except Exception as e:
        logging.error(f"Error analyzing student response: {str(e)}")
        raise

def get_multilingual_content(content, target_language):
    """
    Translate content to the target language using OpenAI API
    """
    try:
        system_prompt = f"""
        You are VidyAI++, an advanced educational AI translator. Translate the following educational content into {target_language}.
        Maintain the educational value and clarity of the original content.
        Ensure that the translation is culturally appropriate and uses common terminology in {target_language}.
        Return the translated content in the same format as the original.
        """
        
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Translate to {target_language}:\n{content}"}
            ],
            max_tokens=1500
        )
        
        return response.choices[0].message.content
        
    except Exception as e:
        logging.error(f"Error translating content: {str(e)}")
        raise

def recommend_content(user_id):
    """
    Recommend learning content based on student profile and history
    """
    try:
        from app import db
        
        # Get student profile and recent activities
        student_profile = StudentProfile.query.filter_by(user_id=user_id).first()
        user = User.query.get(user_id)
        
        if not student_profile:
            return []
        
        # Get completed activities
        completed_activities = LearningActivity.query.filter_by(
            user_id=user_id,
            completed=True
        ).order_by(LearningActivity.end_time.desc()).limit(10).all()
        
        # Extract content IDs and subjects
        completed_content_ids = [activity.content_id for activity in completed_activities]
        
        # Get content details
        completed_contents = []
        subjects_studied = set()
        for content_id in completed_content_ids:
            content = LearningContent.query.get(content_id)
            if content:
                completed_contents.append(content)
                subjects_studied.add(content.subject)
        
        # Find similar content that the student hasn't seen yet
        recommended = []
        
        # 1. Find content of similar difficulty
        difficulty_range = (student_profile.difficulty_level - 1, student_profile.difficulty_level + 1)
        difficulty_recs = LearningContent.query.filter(
            ~LearningContent.id.in_(completed_content_ids),
            LearningContent.difficulty_level.between(difficulty_range[0], difficulty_range[1]),
            LearningContent.language == user.preferred_language
        ).limit(3).all()
        
        recommended.extend(difficulty_recs)
        
        # 2. Find content in subjects of interest
        if student_profile.subjects_of_interest:
            interests = student_profile.subjects_of_interest.split(',')
            for interest in interests:
                interest = interest.strip()
                interest_recs = LearningContent.query.filter(
                    ~LearningContent.id.in_(completed_content_ids),
                    LearningContent.subject.contains(interest),
                    LearningContent.language == user.preferred_language
                ).limit(2).all()
                
                recommended.extend(interest_recs)
        
        # Remove duplicates
        recommended = list({content.id: content for content in recommended}.values())
        
        # Return the recommended content (limit to 5)
        return recommended[:5]
        
    except Exception as e:
        logging.error(f"Error recommending content: {str(e)}")
        return []
