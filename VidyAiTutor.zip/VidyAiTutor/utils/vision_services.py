import io
import cv2
import numpy as np
import base64
import logging
from PIL import Image
import os
import tempfile

# Try to import DeepFace, but don't fail if it's not available
USE_DEEPFACE = False
try:
    from deepface import DeepFace
    USE_DEEPFACE = True
except (ImportError, TypeError) as e:
    logging.warning(f"DeepFace import failed: {str(e)}. Will use fallback methods for emotion detection.")

def detect_emotion(image_file):
    """
    Detect emotion from image using DeepFace or a fallback method
    """
    # Use fallback if DeepFace is not available
    if not USE_DEEPFACE:
        logging.info("Using fallback emotion detection method")
        return fallback_emotion_detection(image_file)
    
    try:
        # Save the image file to a temporary file
        with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as temp:
            temp_filename = temp.name
            image_file.save(temp_filename)
        
        # Analyze emotions using DeepFace
        result = DeepFace.analyze(
            img_path=temp_filename,
            actions=['emotion'],
            enforce_detection=False
        )
        
        # Clean up temporary file
        os.unlink(temp_filename)
        
        # Extract the dominant emotion and confidence
        emotions = result[0]['emotion']
        dominant_emotion = max(emotions, key=emotions.get)
        confidence = emotions[dominant_emotion] / 100.0  # Convert to 0-1 scale
        
        return {
            'emotion': dominant_emotion,
            'confidence': confidence,
            'all_emotions': emotions
        }
        
    except Exception as e:
        logging.error(f"Error detecting emotion with DeepFace: {str(e)}")
        return fallback_emotion_detection(image_file)

def fallback_emotion_detection(image_file):
    """
    Simple fallback emotion detection using basic OpenCV face detection
    """
    try:
        # Read image
        image_bytes = io.BytesIO(image_file.read())
        image_file.seek(0)  # Reset file pointer
        pil_image = Image.open(image_bytes)
        img = np.array(pil_image)
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        
        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Load face cascade
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        
        # Detect faces
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        
        # Simple heuristic: if faces detected, assume neutral, otherwise unknown
        if len(faces) > 0:
            emotion = 'neutral'
            confidence = 0.7
        else:
            emotion = 'unknown'
            confidence = 0.5
        
        # Return basic emotion data
        return {
            'emotion': emotion,
            'confidence': confidence,
            'all_emotions': {
                'angry': 0,
                'disgust': 0,
                'fear': 0,
                'happy': 0,
                'sad': 0,
                'surprise': 0,
                'neutral': 70 if emotion == 'neutral' else 0,
                'unknown': 50 if emotion == 'unknown' else 0
            }
        }
    
    except Exception as e:
        logging.error(f"Error in fallback emotion detection: {str(e)}")
        
        # Return default values if detection completely fails
        return {
            'emotion': 'neutral',
            'confidence': 0.5,
            'all_emotions': {
                'angry': 0,
                'disgust': 0,
                'fear': 0,
                'happy': 0,
                'sad': 0,
                'surprise': 0,
                'neutral': 100
            },
            'error': str(e)
        }

def track_engagement(image_file):
    """
    Track user engagement using eye tracking and face analysis
    """
    try:
        # Read image
        image_bytes = io.BytesIO(image_file.read())
        image_file.seek(0)  # Reset file pointer
        pil_image = Image.open(image_bytes)
        img = np.array(pil_image)
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        
        # Load face cascade classifier
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
        
        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Detect faces
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        
        # Initialize engagement metrics
        face_detected = len(faces) > 0
        eyes_detected = False
        eye_movement = 0
        engagement_level = 0.0
        
        # Process each detected face
        for (x, y, w, h) in faces:
            # Extract face ROI
            roi_gray = gray[y:y+h, x:x+w]
            
            # Detect eyes in the face
            eyes = eye_cascade.detectMultiScale(roi_gray)
            eyes_detected = len(eyes) > 0
            
            # Simple heuristic for engagement
            if eyes_detected:
                engagement_level = 0.8  # High engagement if eyes are detected
            else:
                engagement_level = 0.5  # Medium engagement if only face is detected
        
        # If no face detected, low engagement
        if not face_detected:
            engagement_level = 0.2
        
        # Get emotion data
        emotion_data = detect_emotion(image_file)
        
        # Adjust engagement based on emotion
        emotion_engagement_map = {
            'happy': 0.2,
            'surprise': 0.1,
            'neutral': 0.0,
            'sad': -0.1,
            'angry': -0.2,
            'disgust': -0.2,
            'fear': -0.1
        }
        
        # Apply emotion adjustment
        emotion_adjustment = emotion_engagement_map.get(emotion_data['emotion'], 0.0)
        engagement_level = max(0.0, min(1.0, engagement_level + emotion_adjustment))
        
        return {
            'face_detected': face_detected,
            'eyes_detected': eyes_detected,
            'engagement_level': engagement_level,
            'emotion': emotion_data['emotion']
        }
        
    except Exception as e:
        logging.error(f"Error tracking engagement: {str(e)}")
        
        # Return default values if tracking fails
        return {
            'face_detected': False,
            'eyes_detected': False,
            'engagement_level': 0.5,
            'emotion': 'unknown',
            'error': str(e)
        }

def analyze_learning_state(engagement_history, emotion_history):
    """
    Analyze learning state based on engagement and emotion history
    """
    try:
        # Calculate average engagement
        avg_engagement = sum(entry['engagement_level'] for entry in engagement_history) / len(engagement_history)
        
        # Count emotions
        emotion_counts = {}
        for entry in emotion_history:
            emotion = entry['emotion']
            emotion_counts[emotion] = emotion_counts.get(emotion, 0) + 1
        
        # Determine dominant emotion
        dominant_emotion = max(emotion_counts, key=emotion_counts.get) if emotion_counts else 'neutral'
        
        # Analyze learning state
        if avg_engagement > 0.7:
            if dominant_emotion in ['happy', 'surprise', 'neutral']:
                learning_state = 'optimal'
            else:
                learning_state = 'engaged_but_struggling'
        elif avg_engagement > 0.4:
            if dominant_emotion in ['neutral', 'sad']:
                learning_state = 'passive_learning'
            else:
                learning_state = 'distracted'
        else:
            learning_state = 'disengaged'
        
        return {
            'average_engagement': avg_engagement,
            'dominant_emotion': dominant_emotion,
            'learning_state': learning_state,
            'recommendations': get_learning_recommendations(learning_state)
        }
        
    except Exception as e:
        logging.error(f"Error analyzing learning state: {str(e)}")
        return {
            'average_engagement': 0.5,
            'dominant_emotion': 'neutral',
            'learning_state': 'unknown',
            'recommendations': ['Take a short break and try again'],
            'error': str(e)
        }

def get_learning_recommendations(learning_state):
    """
    Get recommendations based on learning state
    """
    recommendations = {
        'optimal': [
            'Continue with current learning pace',
            'Consider increasing difficulty slightly',
            'Try solving more challenging problems'
        ],
        'engaged_but_struggling': [
            'Review the current concept more thoroughly',
            'Try an alternative explanation of the topic',
            'Break down complex problems into smaller steps'
        ],
        'passive_learning': [
            'Introduce interactive elements to increase engagement',
            'Try a different learning format (video, quiz, etc.)',
            'Take a short break before continuing'
        ],
        'distracted': [
            'Take a 5-minute break',
            'Switch to a different subject temporarily',
            'Try a more engaging learning format'
        ],
        'disengaged': [
            'Take a longer break',
            'Consider ending the session and returning later',
            'Switch to a completely different learning activity'
        ],
        'unknown': [
            'Take a short break and try again',
            'Check your camera setup',
            'Try a different learning format'
        ]
    }
    
    return recommendations.get(learning_state, recommendations['unknown'])
