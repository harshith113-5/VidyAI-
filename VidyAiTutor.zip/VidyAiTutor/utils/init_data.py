from app import db
from models import LearningContent, Language

def init_default_content():
    """
    Initialize default learning content if none exists
    """
    # Check if we already have content
    if LearningContent.query.count() > 0:
        return
    
    # Create sample content
    sample_contents = [
        {
            "title": "Introduction to Basic Addition",
            "description": "Learn the fundamentals of addition with single-digit numbers",
            "content_type": "text",
            "difficulty_level": 1,
            "subject": "Mathematics",
            "language": Language.ENGLISH,
            "content": '{"title":"Introduction to Basic Addition","introduction":"Addition is one of the fundamental operations in mathematics. It helps us combine quantities and find totals.","content":"Let\'s start with some simple addition facts:\\n\\n1 + 1 = 2\\n2 + 2 = 4\\n3 + 3 = 6\\n\\nAddition can be visualized using objects. For example, if you have 2 apples and get 3 more, you will have 5 apples in total.\\n\\nThe plus sign (+) indicates addition. The numbers being added are called addends, and the result is called the sum.","summary":"Addition helps us combine quantities. We use the + sign for addition, and the result is called the sum.","questions":["What is 4 + 3?","If you have 5 toys and get 2 more, how many toys do you have in total?","What is the sum of 6 and 6?"],"activities":["Count objects around you and add them","Draw 3 stars, then draw 4 more stars, and count the total","Play a board game where you need to add numbers on dice"]}',
            "prerequisites": "",
            "learning_outcomes": "Understand basic addition, Apply addition to solve simple problems"
        },
        {
            "title": "My Five Senses",
            "description": "Learn about the five senses and how they help us experience the world",
            "content_type": "text",
            "difficulty_level": 1,
            "subject": "Science",
            "language": Language.ENGLISH,
            "content": '{"title":"My Five Senses","introduction":"Our five senses help us understand the world around us. They are seeing, hearing, smelling, tasting, and touching.","content":"1. Seeing (Vision): We use our eyes to see colors, shapes, and movements.\\n\\n2. Hearing (Auditory): We use our ears to hear sounds like music, voices, and animal noises.\\n\\n3. Smelling (Olfactory): We use our nose to smell things like flowers, food, and perfumes.\\n\\n4. Tasting (Gustatory): We use our tongue to taste sweet, sour, salty, and bitter foods.\\n\\n5. Touching (Tactile): We use our skin to feel textures, temperatures, and pressure.","summary":"Our five senses are seeing, hearing, smelling, tasting, and touching. Each sense helps us experience the world in a different way.","questions":["Which sense do we use to see colors?","Which body part do we use for hearing?","Name one thing you can smell with your nose."],"activities":["Blindfold game: Identify objects by touch only","Sound hunt: Listen and identify different sounds around you","Taste test: Try foods with different tastes and describe them"]}',
            "prerequisites": "",
            "learning_outcomes": "Identify the five senses, Understand how each sense works"
        },
        {
            "title": "हिंदी वर्णमाला (Hindi Alphabet)",
            "description": "Learn the basics of Hindi alphabet and simple words",
            "content_type": "text",
            "difficulty_level": 1,
            "subject": "Language",
            "language": Language.HINDI,
            "content": """{"title":"हिंदी वर्णमाला","introduction":"हिंदी वर्णमाला में स्वर और व्यंजन होते हैं। आइए हम हिंदी के मूल अक्षरों को सीखें।","content":"स्वर (Vowels):\\nअ, आ, इ, ई, उ, ऊ, ए, ऐ, ओ, औ\\n\\nव्यंजन (Consonants):\\nक, ख, ग, घ, ङ\\nच, छ, ज, झ, ञ\\nट, ठ, ड, ढ, ण\\nत, थ, द, ध, न\\nप, फ, ब, भ, म\\nय, र, ल, व\\nश, ष, स, ह\\n\\nकुछ सरल शब्द:\\nअम = mango\\nकल = tomorrow\\nजल = water\\nघर = house\\nनल = tap","summary":"हिंदी वर्णमाला में 10 स्वर और 40 व्यंजन होते हैं। इन अक्षरों से मिलकर शब्द बनते हैं।","questions":["क के बाद कौन सा अक्षर आता है?","अ क्या है - स्वर या व्यंजन?","घर का क्या अर्थ है?"],"activities":["अक्षरों को लिखने का अभ्यास करें","अपने नाम के अक्षरों की पहचान करें","चित्र देखकर उनके नाम के पहले अक्षर बताएं"]}""",
            "prerequisites": "",
            "learning_outcomes": "Learn Hindi vowels and consonants, Recognize and write basic Hindi alphabets"
        }
    ]
    
    for content_data in sample_contents:
        content = LearningContent(**content_data)
        db.session.add(content)
    
    db.session.commit()

def init_default_data():
    """
    Initialize default data for the application
    """
    # Initialize content
    init_default_content()
