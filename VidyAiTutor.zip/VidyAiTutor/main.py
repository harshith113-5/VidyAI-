from app import app  # noqa: F401

# This file is configured so that the run command will work by default
